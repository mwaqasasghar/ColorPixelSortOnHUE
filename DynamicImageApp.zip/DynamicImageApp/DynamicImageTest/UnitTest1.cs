﻿using System;
using ColorPixelSortLibrary;
using ColorPixelSortLibrary.Helpers;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DynamicImageTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void GetRandomARGB()
        {
            //Setup
            Random random = new Random();

            //Act
            var (a, b, c, d) = RandomPixel.RandomARGB(random);

            //Assert
            if (a < 0 || b < 0 || c < 0 || d < 0)
            {
                Assert.Fail();
            }
        }
    }
}
