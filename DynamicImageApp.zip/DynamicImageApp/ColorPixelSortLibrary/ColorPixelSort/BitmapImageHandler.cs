﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using ColorPixelSortLibrary.ColorPixelSortInterfaces;
using DynamicImageApp.Models;

namespace ColorPixelSortLibrary.ColorPixelSort
{
   public class BitmapImageCustomHandler:IBitmapImageHandler
    {

        public Bitmap CreateNewBitmapForSortedColors(List<HueModel> hues, int imageWidth, int imageHeight)
        {
            Queue<HueModel> hueModelQueue = new Queue<HueModel>(hues.OrderBy(xAxis => xAxis.Hue));
            Bitmap bitmap = new Bitmap(imageWidth, imageHeight);
            for (int yAxis = 0; yAxis < imageWidth; yAxis++)
            {
                for (int xAxis = 0; xAxis < imageHeight; xAxis++)
                {
                    HueModel HUE = hueModelQueue.Dequeue();
                    bitmap.SetPixel(yAxis, xAxis, Color.FromArgb(HUE.Alpha, HUE.Red, HUE.Green, HUE.Blue));
                }
            }

            return bitmap;
        }
    }
}
