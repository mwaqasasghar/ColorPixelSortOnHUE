﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Media.Imaging;
using ColorPixelSortLibrary.ColorPixelSortInterfaces;
using ColorPixelSortLibrary.Helpers;
using DynamicImageApp.Models;

namespace ColorPixelSortLibrary.ColorPixelSort
{
    public class CreateRandomColorPixelsScreen : ICreateRandomColorPixelsScreen
    {
        private readonly List<HueModel> hues = new List<HueModel>();
        public BitmapImage CreateRandomColorPixelImage(int heightofBitmapImage, int WidthofBitmapImage)
        {
            Bitmap bitmapForRandomColorPixelsImage = new Bitmap(WidthofBitmapImage, heightofBitmapImage);
            Random randomValueForPixels = new Random();

            for (int yAxis = 0; yAxis < heightofBitmapImage; yAxis++)
            {
                for (int xAxis = 0; xAxis < WidthofBitmapImage; xAxis++)
                {
                    (int alpha, int red, int green, int blue) = RandomPixel.RandomARGB(randomValueForPixels);
                    bitmapForRandomColorPixelsImage.SetPixel(xAxis, yAxis, Color.FromArgb(alpha, red, green, blue));
                    AddHue(alpha, red, green, blue);
                }
            }

            return ImageFormat.BitmapToImage(bitmapForRandomColorPixelsImage);
        }
        private void AddHue(int alpha, int red, int green, int blue)
        {
            float hue = Color.FromArgb(alpha, red, green, blue).GetHue();
            hues.Add(new HueModel
            {
                Alpha = alpha,
                Red = red,
                Green = green,
                Blue = blue,
                Hue = hue
            });
        }

        public List<HueModel> GetHues()
        {
            return hues;
        }
    }
}