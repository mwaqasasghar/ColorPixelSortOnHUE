﻿using System.Collections.Generic;
using System.Drawing;
using DynamicImageApp.Models;

namespace ColorPixelSortLibrary.ColorPixelSortInterfaces
{
    public interface IBitmapImageHandler
    {
        Bitmap CreateNewBitmapForSortedColors(List<HueModel> hues, int imageWidth, int imageHeight);
    }
}
