﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Net.Mime;
using System.Text;
using System.Windows.Media.Imaging;
using DynamicImageApp.Models;

namespace ColorPixelSortLibrary.ColorPixelSortInterfaces
{
    public interface ICreateRandomColorPixelsScreen
    {
        BitmapImage CreateRandomColorPixelImage(int height, int width);
        List<HueModel> GetHues();
    }
}
