﻿using System;

namespace ColorPixelSortLibrary.Helpers
{
    public static class RandomPixel
    {
        private const int RandomRange = 256;
        public static (int, int, int, int) RandomARGB(Random random)
        {
            return (random.Next(RandomRange), random.Next(RandomRange), random.Next(RandomRange), random.Next(RandomRange));
        }
    }
}
