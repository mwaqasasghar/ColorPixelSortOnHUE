﻿namespace DynamicImageApp.Models
{
    public class HueModel
    {
        public float Hue { get; set; }
        public int Alpha { get; set; }
        public int Red { get; set; }
        public int Green { get; set; }
        public int Blue { get; set; }
    }
}
