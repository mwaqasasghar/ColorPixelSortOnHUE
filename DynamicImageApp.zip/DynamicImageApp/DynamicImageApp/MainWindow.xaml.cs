﻿using DynamicImageApp.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Windows;
using ColorPixelSortLibrary.ColorPixelSort;
using ColorPixelSortLibrary.ColorPixelSortInterfaces;
using ColorPixelSortLibrary;
using ImageFormat = ColorPixelSortLibrary.Helpers.ImageFormat;

namespace DynamicImageApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const int ImageHeight = 200;
        private const int ImageWidth = 400;

        private readonly ICreateRandomColorPixelsScreen _createRandomColorPixelsScreen=new CreateRandomColorPixelsScreen();
        private readonly IBitmapImageHandler _bitmapImageHandler=new BitmapImageCustomHandler();

        private List<HueModel> hues = new List<HueModel>();


        public MainWindow()
        {
            InitializeComponent();
        }

        private void CreateRandomColorPixelImageButtonClick(object sender, RoutedEventArgs e)
        {
            imgDynamic.Source = _createRandomColorPixelsScreen.CreateRandomColorPixelImage(ImageHeight,ImageWidth);
            hues = _createRandomColorPixelsScreen.GetHues();
        }

        private void SortColorButtonClick(object sender, RoutedEventArgs e)
        {
            if (CheckhuesExists()) return;

            Bitmap sortedBitmapForSortedColorPixelsOnHueValue = _bitmapImageHandler.CreateNewBitmapForSortedColors(hues,ImageWidth,ImageHeight);
            imgDynamic.Source = ImageFormat.BitmapToImage(sortedBitmapForSortedColorPixelsOnHueValue);

        }

        private bool CheckhuesExists()
        {
            if (hues.Count == 0)
            {
                return true;
            }

            return false;
        }
    }
}
